<?php
// require("../../config/init.php");

$q= $db->prepare("SELECT * FROM bills WHERE bill_number= ? ");
$q->execute([$bill_number]);
$bill = $q->fetch(PDO::FETCH_OBJ);

$req = $db->prepare("SELECT * FROM articles_bill WHERE bill_number = ?");
$req->execute([$bill_number]);
$articles = $req->fetchAll();

?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Bienvenu à Opty Clean</title>
	<style type="text/css">
        @import url('https://fonts.googleapis.com/css?family=Lobster&display=swap');

		.container{
			width: 500px; 
			margin: 50px auto;
			border-radius: 10px;
		}
		.header{
			width: 100%;
			border-top-left-radius: 10px;
            border-top-right-radius: 10px;
		}
		.header h1{
			color: #00b6bc;
			font-size: 45px;
			font-family: "Lucida Calligraphy";
			font-weight: bold;
			font-style: italic;
		}
		p{
			font-size: 18px;
			font-family: "Lucida Sans";
            color: #232523;
            text-align: justify;
		}
		.link{
			display: inline-block;
			text-decoration: none;
			padding: 20px;
			border:1px solid #ce2135;
			border-radius: 10px;
			color: #ce2135;
			font-size: 16px;
			font-family: Arial;
		}
        
        table {
        border: 1px solid #ccc;
        border-collapse: collapse;
        margin: 0;
        padding: 0;
        width: 90%;
        table-layout: fixed;
        }

        table tr {
        background-color: #f8f8f8;
        border: 1px solid #ddd;
        padding: .35em;
        }

        table th,
        table td {
        padding: .625em;
        text-align: center;
        }

        table th {
        font-size: .85em;
        letter-spacing: .1em;
        text-transform: uppercase;
        }

        @media screen and (max-width: 600px) {
        table {
            border: 0;
        }
        
        table tr {
            border-bottom: 3px solid #ddd;
            /* display: block; */
            margin-bottom: .625em;
        }
        }

	</style>
</head>
<body>

	<div class="container">
		<div class="header">
			<h1>Opty Clean</h1>
		</div>
		<div class="contain">
			<p>Hello,</p>
			<p>
                Code de l'article: <strong><?= e($bill->article_code) ?></strong>
                <br>
                Date de Retrait: <?php setlocale(LC_TIME, "fr_FR", "French"); echo strftime('%A %d %B %G', strtotime($bill->retreived_date)) ?>
                <br>
                Total: <?= e($bill->amount); ?> FCFA
            </p>
            <p>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Articles</th>
                            <th scope="col" class="center">Qte</th>
                            <th scope="col" class="right">PU</th>
                            <th scope="col" class="right">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach($articles as $article): extract($article)?>
                    <?php 
                        $article_name = get_value('article_name', 'articles', 'article_id', $article_id);
                        $article_price = get_value('price', 'articles', 'article_id', $article_id);
                    ?>
                        <tr>
                            <td data-label="Article" class="left strong"><?= ucwords($article_name) ?></td>
                            <td data-label="Qte" class="left"><?= e($quantity) ?></td>
                            <td data-label="PU" class="right"><?= number_format($article_price) ?> FCFA</td>
                            <td data-label="Total" class="right"><?= number_format($quantity * $article_price) ?> FCFA</td>
                        </tr>
                    <?php endforeach ?>
                    </tbody>
                </table>
            </p>
			<p>
				L'equipe Opty Clean
			</p>
		</div>
		<hr>
		<div class="footer">
			<p style="color: grey; font-size: 14px">
                Si vous avez besoin d'aide, envoyez-nous un mail à cette adresse. <br>
				&copy; <?= date('Y') ?> Opty Clean Ltd.
			</p>
		</div>
	</div>

</body>
</html>