<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>
        <?= 
            isset($title) 
            ? $title . ' - ' . WEBSITE_NAME
            : WEBSITE_NAME;
        ?>
     </title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Alertify CSS -->
    <link href="libraries/alertifyjs/css/alertify.min.css" rel="stylesheet">
    <link href="libraries/alertifyjs/css/themes/default.min.css" rel="stylesheet">

    <!-- JQuery UI CSS -->
    <link rel="stylesheet" href="libraries/jquery-ui/jquery-ui.min.css">
    <link rel="stylesheet" href="libraries/jquery-ui/jquery-ui.theme.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="libraries/fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="libraries/fontawesome/css/solid.min.css">

    <!-- DataTables -->
    <link rel="stylesheet" href="libraries/DataTables/DataTables/css/dataTables.bootstrap4.min.css">

    <!-- Core Css -->
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/utils.css">


    <link rel="icon" href="docs/4.4/assets/img/favicons/favicon.ico">
</head>
<body>