    <script src="/assets/js/jquery.min.js"></script>
    <script src="/assets/js/popper.min.js"></script>
    <script src="/assets/js/bootstrap.min.js"></script>

    <!-- App|Core JS --> 
    <script src="/assets/js/app.js"></script>
    <script src="/assets/js/facture.js"></script>
    
    <!-- jQuery UI Js -->
    <script type="text/javascript" src="/libraries/jquery-ui/jquery-ui.min.js"></script>

    <!-- Fontawesome JS -->
    <script src="/libraries/fontawesome/js/fontawesome.min.js"></script>
    <script src="/libraries/fontawesome/js/solid.min.js"></script>

    <!-- Sweetalert -->
    <script src="/libraries/sweetalert/dist/sweetalert2.all.min.js"></script>

    <!-- PrintThis -->
    <script src="/libraries/printthis/printThis.js"></script>
    <!-- <script src="/assets/js/print.js"></script> -->

    <script src="https://kendo.cdn.telerik.com/2017.2.621/js/jszip.min.js"></script>
    <script src="https://kendo.cdn.telerik.com/2017.2.621/js/kendo.all.min.js"></script>

    <!-- DataTable -->
    <script src="/libraries/DataTables/datatables.min.js"></script>
    <script src="/libraries/DataTables/DataTables/js/dataTables.bootstrap4.min.js"></script>

    <!-- Alertifyjs -->
    <script src="/libraries/alertifyjs/alertify.min.js"></script>
    <?php
        if(isset($_SESSION['alertify'])){
            echo $_SESSION['alertify'];
            unset($_SESSION['alertify']);
        }
    ?>

    <script type="text/javascript">
        $(document).ready(function(){
            $('#table').DataTable({
                "language": {
                    "lengthMenu": "Afficher _MENU_ résultats par page",
                    "zeroRecords": "Aucun résultat trouvé - désolé",
                    "info": "Affichage de la page _PAGE_ sur _PAGES_",
                    "infoEmpty": "Aucun résultat disponible",
                    "infoFiltered": "(filtré de _MAX_ résultat total)",
                    "emptyTable": "Aucune donnée trouvée",
                    "search": "Rechercher:",
                    "paginate": {
                        "next": "Suivant",
                        "previous": "Précédent"
                    } 
                }
            });
        });

        $('#return-date').datepicker({
            monthNames: ["Janvier", "février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Aout", "Septembre", "Octobre","Novembre", "Décembre"],
            dayNamesMin: [ "Di", "Lu", "Ma", "Me", "Je", "Ve", "Sa" ],
            dateFormat: "dd/mm/yy",
            minDate: new Date()
        });
    </script>

<script>
     function ExportPdf(){ 
        kendo.drawing
            .drawDOM("#printContent", 
            { 
                paperSize: "A5",
                margin: { top: "0", bottom: "0" },
                scale: 0.8,
                width: 210,
                height: 100,
            })
                .then(function(group){
                kendo.drawing.pdf.saveAs(group, "Exported.pdf")
            });
        }
</script>
</body>
</html>