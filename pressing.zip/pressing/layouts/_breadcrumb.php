<?php
    $url = $_SERVER['REQUEST_URI'];
    $url = trim($url, '/');

    $pages = explode('/', $url);
?>
<?php if($user && getPageName() != "accueil" && getPageName() != ""): ?>
<div class="breadcrumb">
    <a href="/accueil" class="breadcrumb-item">Accueil</a>
    <?php for($i = 0; $i < count($pages) ; $i++): ?>
        <?php if(getPageName() == $pages[$i]): ?>
            <span class="breadcrumb-item"><?= $title ?></span>
        <?php else: ?>
            <a href="/<?= ((count($pages) > 3) ? $pages[$i - 1] . DIRECTORY_SEPARATOR : '') . $pages[$i] ?>" class="breadcrumb-item"><?= ucwords(str_replace('-', ' ', $pages[$i])) ?></a>
        <?php endif; ?>
    <?php endfor; ?>
</div>
<?php endif ?>