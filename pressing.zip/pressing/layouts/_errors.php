<?php if(isset($errors) && count($errors) != 0): ?>
<div class="alert alert-danger">
    <?php foreach($errors as $error): ?>
        <?= $error . "<br/>" ?>
    <?php endforeach ?>
</div>
<?php endif ?>