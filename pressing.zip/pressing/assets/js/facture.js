$(document).ready(function() {
  var count = 1;
  $("#add").click(function() { 
    count++;
    var html_code = "<tr id='row" + count + "'>";
    html_code +=
      "<td class='article-td'><select class='article form-control' name='article' onclick='getOptions(this)' onchange='getArticlePrice(this)'><option value=''>Selectionez un article</option></select></td>";
    html_code +=
      "<td class='quantity-td'><input type='text' name='quantity' class='quantity form-control' onkeyup='quantity(this)'></td>";
    html_code +=
      "<td class='price-td'><input type='number' name='price' class='price form-control' readonly><input type='hidden' name='up' class='up'></td>";
    html_code +=
      "<td class='action'><button type='button' name='remove' class='btn btn-danger' id='remove' data-row='row" +
      count +
      "'>-</button></td>";
    html_code += "</tr>";

    $(".table").append(html_code);
  });

  $(document).on("click", "#remove", function() {
    var delete_row = $(this).data("row");
    $("#" + delete_row).remove();
    getTotal();
  });

  $("#save").click(function() {
    var articles = [];
    var quantities = [];
    var prices = [];
    var total = $(".total").val();
    var amount_paid = $('.amount_paid').val();
    var return_date = $("#return-date").val();
    var customer_id = $(".customer_id").val();
    var article_code = $(".article_code").val();
    var bill_number = $(".bill_number").val();

    $(".article").each(function() {
      articles.push($(this).val());
    });
    $(".quantity").each(function() {
      quantities.push($(this).val());
    });
    $(".price").each(function() {
      prices.push($(this).val());
    });

    if(articles.length <= 0 || quantities.length <= 0 || prices.length <= 0 || return_date == "" || customer_id == "" || amount_paid == "" || NoneEmpty(articles) == false || NoneEmpty(quantities) == false || NoneEmpty(prices) == false){
      getMessage("veillez remplir tous les champs", 'error')
    }else if(hasDoubleElement(articles) == true){
      getMessage("Article double trouvé", 'error')
    }else if(amount_paid <= 0 || Number(amount_paid) > Number(total)){
      getMessage("Montant Invalide", 'error')
    }else{
      $.ajax({
        url: "/insertBill.php",
        method: "POST",
        data: {
          bill_number: bill_number,
          articles: articles,
          quantities: quantities,
          prices: prices,
          total: total,
          amount_paid: amount_paid,
          return_date: return_date,
          customer_id: customer_id,
          article_code: article_code
        },
        success: function(data){
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 2000,
            timerProgressBar: true,
            onOpen: (toast) => {
              toast.addEventListener('mouseenter', Swal.stopTimer)
              toast.addEventListener('mouseleave', Swal.resumeTimer)
            },
            onClose: () => {
              window.location = "/factures/en-cours"
            }
          })
          Toast.fire({
            icon: 'success',
            title: data
          })
        }
      });  
    }
  });

  //Récupérer le nom de client
  $("#customer_name").focus(function() {
    $("#customer_name").keyup(function() {
      var customer_name = $("#customer_name").val();

      if (customer_name !== "") {
        $.post(
          "/getCustomerName.php",
          { customer_name: customer_name },
          function(data) {
            $(".customer-name")
              .html(data)
              .show();

            $("a.list-group-item").on("click", function() {
              var link = $(this).text();
              var customer_id = this.dataset.customer;

              $(".customer_id").val(customer_id);
              $("#customer_name").val(link);
              $(".list-group").hide();
            });
          }
        );
      } else {
        $(".list-group").hide();
      }
    });
  });
});

function getOptions(e) {
  var article = e.value;
  var parentId = e.parentNode.parentNode.id;

  $.post("/getOptions.php", { article: article }, function(data) {
    if ($("#" + parentId + " .article option").length <= 1) {
      $("#" + parentId + " .article").append(data);
    }
  });
}

function getArticlePrice(e) {
  var article = e.value;
  var parentId = e.parentNode.parentNode.id;

  $.post("/getArticlePrice.php", { article: article }, function(data) {
    if ($("#" + parentId + " .quantity").val() == "") {
      $("#" + parentId + " .price").val(data);
    } else {
      $("#" + parentId + " .price").val(
        $("#" + parentId + " .quantity").val() * data
      );
    }
    $("#" + parentId + " .up").val(data);

    getTotal();
  });
}

function quantity(e) {
  var parentId = e.parentNode.parentNode.id;
  var quantity = e.value;
  var up = $("#" + parentId + " .up").val();
  var total_price = $("#" + parentId + " .quantity").val() * up;

  if (quantity != "" && quantity > 0) {
    $("#" + parentId + " .price").val(total_price);
  } else {
    $("#" + parentId + " .price").val(up);
  }

  getTotal();
}

function getTotal() {
  var total = 0;
  var prices = document.querySelectorAll(".price");
  prices.forEach(function(price) {
    total = Number(price.value) + Number(total);
  });

  $(".total").val(total);
}

function NoneEmpty(arr) {
  for(var i=0; i<arr.length; i++) {
    if(arr[i] === "") return false;
  }
  return true;
}

function hasDoubleElement(arr){
  var i, j, count = 0;
  for (i = 0; i < arr.length; i++){
    for(j = 0; j < arr.length; j++){
      if(arr[i] === arr[j]){
        count++
      }
    }

    if(count >= 2){
      return true
    }else{
      count = 0;
    }
  }
}

function getMessage(message, type){
  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    onOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer)
      toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
  })
  Toast.fire({
    icon: type,
    title: message
  })
}

function preventChar(e){
  var keyCode = ('which' in event) ? event.which : event.keyCode;

  isNumeric = (keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105)
  modifier = (event.altKey || event.ctrlKey || event.shiftKey)
  return isNumeric || modifier
}