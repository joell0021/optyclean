jQuery(function($){
    // $('#printButton').click(function(){
    //     $('#printContent').printThis({
    //         debug: false,               // show the iframe for debugging
    //         importCSS: true,            // import parent page css
    //         importStyle: false,         // import style tags
    //         printContainer: false,       // print outer container/$.selector
    //         loadCSS: "file:///C:/xampp/htdocs/pressing/public/assets/css/bootstrap.css",                // path to additional css file - use an array [] for multiple
    //         pageTitle: "<h1>Opty Pressing</h1>",              // add title to print page
    //         removeInline: false,        // remove inline styles from print elements
    //         removeInlineSelector: "*",  // custom selectors to filter inline styles. removeInline must be true
    //         printDelay: 333,            // variable print delay
    //         header: null,               // prefix to html
    //         footer: null,               // postfix to html
    //         base: false,                // preserve the BASE tag or accept a string for the URL
    //         formValues: true,           // preserve input/form values
    //         canvas: false,              // copy canvas content
    //         doctypeString: '...',       // enter a different doctype for older markup
    //         removeScripts: false,       // remove script tags from print content
    //         copyTagClasses: false,      // copy classes from the html & body tag
    //     });
    // })
})