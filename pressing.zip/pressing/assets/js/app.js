function deleteItem(item, id) {
  Swal.fire({
    title: "êtes vous sûr?",
    text: "le processus est irreversible!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Oui, supprimer!",
    cancelButtonText: "Annuler"
  }).then(result => {
    if (result.value) {
      window.location = "/supprimer/" + item + "-" + id
    } else {
      const Toast = Swal.mixin({
        toast: true,
        position: "top-center",
        showConfirmButton: false,
        timer: 1500,
        timerProgressBar: true,
        onOpen: toast => {
          toast.addEventListener("mouseenter", Swal.stopTimer);
          toast.addEventListener("mouseleave", Swal.resumeTimer);
        }
      });

      Toast.fire({
        icon: "error",
        title: "Operation annulé"
      });
    }
  }); 
}
jQuery(function($) {
  $("#profile").on("change", () => {
    var profile = $("#profile").val();
    $.post("/getUsername.php", { profile: profile }, data => {
      $("#username").val(data);
    });

    $.post("/getPassword.php", { profile: profile }, data => {
      $("#password").val(data);
    });
  });
});
