<?php
session_start();

require("filters/auth_filter.php");
require("config/init.php");


if(isset($_POST['login'])){
    if(not_empty(['username', 'password'])){

        //tableau d'erreurs
        $errors = [];

        //extraction de variable utilisateur
        extract($_POST);

        //vérifier si il y'a aucune erreur dans le formulaire
        if(count($errors) == 0){
            //récuperer l'utilisateur dans la bdd
            $q = $db->prepare("SELECT * FROM users WHERE username = :username");
            $q->execute([
                'username' => e($username)
            ]);

            $user = $q->fetch(PDO::FETCH_OBJ);

            //vérification du mot de passe
            if($user && password_verify(e($password), $user->password)){
                $_SESSION['auth'] = $user->user_id;
                alertify("Connexion réussi", "success");
                redirect("accueil");
            }else{
                $errors[] = "Nom d'utilisateur ou Mot de passe incorrecte";
                save_input_data();
            }
        }

    }else{
        $errors[] = "Veuillez remplir tous les champs svp";
        save_input_data();
    }
}else{
    clear_input_data();
}

require("views/login.view.php");