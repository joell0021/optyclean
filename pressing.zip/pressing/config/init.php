<?php
setlocale(LC_TIME, "fr_FR");

require("database.php");
require("functions.php");
require("constants.php");