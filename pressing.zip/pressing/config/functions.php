<?php
// les valeurs de retours des fonctions ont été mises en commentaires
/**
 * sanitization des données
*/
if(!function_exists('e')){
    function e( $string) /*: string*/{
        return htmlentities(strip_tags(trim($string)));
    }
}

/**
 * Récuperer les informations sur l'utilisateur connecté
 * @return null|stdClass
*/
if(!function_exists('get_user')){
    function get_user() //: stdClass
    {
        global $db;
        if(isset($_SESSION['auth'])){
            $q = $db->prepare("SELECT * FROM users WHERE user_id = ?");
            $q->execute([$_SESSION['auth']]);

            $result = $q->fetch(PDO::FETCH_OBJ);

            if($result == false){
                redirect('deconnexion');
            }
            return $result;
        }
    }
}

/**
 * Verifier si des champs ne sont pas vide
 * @param array $fields
 * @return boolean
*/
if(!function_exists('not_empty')){
    function not_empty(array $fields = []) //: bool
    {
        if(count($fields) != 0){
            foreach($fields as $field){
                if(empty($_POST[$field]) || trim($field) == ""){
                    return false;
                }
            }
            return true;
        }
    }
}

/**
 * rediriger l'utilisateur sur une page specifique
 * @param string $page page de redirection
 * @return void
*/
if(!function_exists('redirect')){
    function redirect(string $page) //: void
    {
        header("HTTP/1.1 301 Moved Permanently");
        header("Location: /" . $page);
        exit();
    }
}

/**
 * stocker des données venant d'un formulaire en session
 * @return void
*/
if(!function_exists('save_input_data')){
    function save_input_data() //: void
    {
        foreach($_POST as $key => $value){
            if(strpos($key, 'password') === false){
                $_SESSION['input'][$key] = $value;
            }
        }
    }
}

/**
 * récuperer des données stocker en session
 * @param string $key
 * @return string|null 
*/
if(!function_exists('get_input')){
    function get_input( $key) //: ?string
    {
        return !empty($_SESSION['input'][$key])
               ? e($_SESSION['input'][$key])
               : null;
    }
}

/**
 * supprimer les données stocker en session
 * @return void
*/
if(!function_exists('clear_input_data')){
    function clear_input_data() //: void
    {
        if(isset($_SESSION['input'])){
            $_SESSION['input'] = [];
        }
    }
}

/**
 * Afficher des notification
 * @param string $message Message à afficher
 * @param string $type Type du message
 * @return string code javascript executer par le navigateur
*/
if(!function_exists('alertify')){
    function alertify( $message,  $type) //: string
    {
        $script = 'alertify.set("notifier", "position", "top-center");
                  var delay = alertify.get("notifier", "delay");
                  alertify.set("notifier", "delay", 5);
                  alertify.'.$type.'("'.$message.'");
                  alertify.set("notifier", "delay", delay)';
        $_SESSION['alertify'] = '<script>'.$script.'</script>';

        return $_SESSION['alertify'];
    }
}

/**
 * Vérifier si une valeur existe déjà dans la bdd
 * @param string $field champs ou pointe la requette
 * @param string $table table sur laquelle on verifie
 * @param string $reference champ dont on verifie l'existance
 * @param mixed $value valeur du champ
 * @return int si la requette affecte plus d'une colone
*/
if(!function_exists('is_already_in_use')){
    function is_already_in_use(string $field, string $table, string $reference, $value)//: int
    {
        global $db;
        $req = $db->prepare("SELECT $field FROM $table WHERE $reference = ?");
        $req->execute([$value]);

        return $req->rowCount();
    }
}

/**
 * réccupere une valeur dans la bdd
 * @param string $field champs ou pointe la requette
 * @param string $table table sur laquelle on verifie
 * @param string $reference champ dont on verifie l'existance
 * @param mixed $value valeur du champ
 * @return mixed la valeur trouvée
*/
if(!function_exists('get_value')){
    function get_value(string $field, string $table, string $reference, $value)//: ?string
    {
        global $db;
        $req = $db->prepare("SELECT $field FROM $table WHERE $reference = ?");
        $req->execute([$value]);

        $result = $req->fetch(PDO::FETCH_OBJ);

        return $result->$field;
    }
}

/**
 * formater le numéro de téléphone
 * @param $phone numéro de téléphone à formaté
 * @return string numéro de téléphone au format 000-000-000
*/
if(!function_exists('formatPhoneNumber')){
    function formatPhoneNumber(string $phone)//: string
    {
        if(preg_match('/^(\d{3})(\d{3})(\d{3})$/', $phone, $matches)){
            $result = $matches[1] . ' ' . $matches[2] . ' ' .$matches[3];
        }
        return $result;
    }
}

/**
 * gener une chaine de caractere aleatoire
 * @param int $length la longueur de la chaine de caractere aleatoire a generer
 * @return string une chaine de caractere aleatoire
*/
if(!function_exists('random')){
    function random(int $length)//: string
    {
        $string = "";
        $characters = "abcdefghijklmnopqrstuvwxyz0123456789";
        srand((float)microtime() * 1000000);
        for($i = 0; $i < $length; ++$i){
            $string .= $characters[rand() % strlen($characters)];
        }
        return $string;
    }
}

/**
 * reccupere les donnees dans la bdd et les stoke dans la balise option utilisee par un select
 * @param array $fields le champs a reccuperer dans la bdd
 * @param string $table la table ou on reccupere les donnees
 * @return void
*/
if(!function_exists('getOption')){
    function getOption(array $fields, string $table)//:void
    {
        global $db;
        $fields = implode(',', $fields);
        $req = $db->prepare("SELECT $fields FROM $table");
        $req->execute();

        $rows = $req->fetchAll();
        foreach($rows as $row){
            echo "<option value='{$row[0]}'>{$row[1]}</option>";
        }
    }
}

if(!function_exists('getOpenInvoice')){
    function getOpenInvoice()//: bool
    {
        global $db;

        $today = date("Y-m-d");

        $req = $db->prepare("SELECT COUNT(bill_number) FROM bills WHERE(retreived_date < :today AND status = :status)");
        $req->execute([
            'today' => $today,
            'status' => 'en-cours'
        ]);

        if($req->fetchColumn() > 0)
            return true;
    
        return false;
    }
}

function getPageName()
{
    $path = $_SERVER['REQUEST_URI'];
    $page = basename($path);
    return $page;
}