<?php

define("WEBSITE_NAME", "Opty-Clean");
define("WEBSITE_URL", "http://pressing.com");