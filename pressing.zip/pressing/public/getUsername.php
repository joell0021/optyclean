<?php
session_start();

require("../config/init.php");

if(isset($_POST['profile']) && !empty($_POST['profile'])){
    extract($_POST);

    $q = $db->prepare("SELECT MAX(user_id) as max_user_id, username FROM users WHERE profile = ?");
    $q->execute([$profile]);

    $user = $q->fetch(PDO::FETCH_OBJ);

    if($user && $user->max_user_id > 0 && !is_null($user->max_user_id)){
        $user_number = substr($user->username, -2);
        $user_number_plus_1 = $user_number + 1;

        if($user_number_plus_1 < 10){
            echo $profile . ' 0' . $user_number_plus_1;
        }else{
            echo $profile . ' ' . $user_number_plus_1;
        }
    }else{
        echo $profile . ' 01';
    }

}