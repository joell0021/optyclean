<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

require('../vendor/autoload.php');

$mail = new PHPMailer(true);

$mail->SMTPDebug = SMTP::DEBUG_SERVER; 