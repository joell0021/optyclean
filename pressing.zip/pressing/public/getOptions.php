<?php
require("../config/init.php");

$req = $db->prepare("SELECT article_id, article_name FROM articles ORDER BY article_name");
$req->execute();

$rows = $req->fetchAll();
foreach ($rows as $row) {
    echo "<option value='{$row['article_id']}'>{$row['article_name']}</option>";
}
