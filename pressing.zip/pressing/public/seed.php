<?php



use Faker\Factory;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require("../config/init.php");
require("../vendor/autoload.php");

// $faker = Factory::create();

// for($i = 0; $i <= 10; $i++){
//     $completeName = $faker->firstName . ' ' . $faker->lastName;
//     $email = $faker->email;
//     $phone = $faker->randomNumber('8', true);
//     $gender = $faker->randomElement(['H', 'F']);

//     $req= $db->prepare("INSERT INTO customers(customer_name, email, phone, gender) VALUES(?, ?, ?, ?)");
//     $req->execute([
//         e($completeName),
//         e($email),
//         e('6'.$phone),
//         e($gender)
//     ]);

// }

$mail = new PHPMailer();

//Server settings
$mail->isSMTP();          
$mail->SMTPDebug = SMTP::DEBUG_SERVER;                                  // Send using SMTP
$mail->Host       = 'smtp.hostinger.com';                    // Set the SMTP server to send through
$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
$mail->Username   = 'optyclean@growthminds.online';                     // SMTP username
$mail->Password   = '3OslijtW';                               // SMTP password
$mail->SMTPSecure = 'tls';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
$mail->Port       = 587; 

//Recipients
$mail->setFrom('optyclean@growthminds.online', 'Opty Clean');
$mail->addAddress('tsopzejael@gmail.com');

// Content
//$mail->isHTML(true);                                  // Set email format to HTML
$mail->Subject = 'Opty Clean';

    

$mail->msgHTML(file_get_contents('mails/customer.mail.html'), 'assets/images' );

if($mail->send()){
    echo "Mail Send";
}else{
    die($mail->ErrorInfo);
}

?>
