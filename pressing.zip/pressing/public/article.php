<?php
session_start();

require("../filters/guest_filter.php");
require("../config/init.php");

$user = get_user();

$req = $db->prepare("SELECT * FROM articles ORDER BY article_name ASC");
$req->execute();
$articles = $req->fetchAll(PDO::FETCH_ASSOC);

if(isset($_POST['add']) || isset($_POST['edit'])){
    if(not_empty(['article_name', 'article_price'])){

        $errors = [];
        extract($_POST);

        if(strlen($article_name) < 3){
            $errors[]= "Nom trop court";
        }elseif(strpbrk($article_name, '0123456789') != false){
            $errors[] = 'Nom invalide';
        }

        if(strlen($article_price) < 3  || !preg_match("/[^0-9]/", $article_price) === false){
            $errors[] = 'Prix invalide';
        }

        if(isset($add) && is_already_in_use('article_id', 'articles', 'article_name', e($article_name)) > 0){
            $errors[] = "Article déjà enregistré";
        }

        if(count($errors) == 0){
            if(isset($edit)){
                $req = $db->prepare("UPDATE articles SET article_name = :article_name, price = :price WHERE article_id = {$article_id}");
            }else{
                $req = $db->prepare("INSERT INTO articles(article_name, price) VALUES(:article_name, :price)");
            }

            $req->execute([
                'article_name' => e($article_name),
                'price' => e($article_price)
            ]);

            if($req){
                alertify("Article " . (isset($edit) ? 'Modifier' : 'Ajouté')  , "success");
                redirect("gestion-des-articles");
            }else{
                $errors[] = "Une erreur est survenu...";
            }
        }else{
            alertify("Une erreur est survenu", "error");
            if(isset($_POST['add'])){
                save_input_data();
            }
        }


    }else{
        $errors[] = "Veuillez remplir tous les champs svp!";
        if(isset($_POST['add'])){
            save_input_data();
        }
    }
}else{
    clear_input_data();
}

require("views/article.view.php");
?>