<?php
require("../config/init.php");

if(isset($_POST['customer_name']) && !empty($_POST['customer_name'])){

    extract($_POST);

    $customer_name = e($customer_name);

    $req = $db->query("SELECT customer_id, customer_name FROM customers WHERE customer_name LIKE '%$customer_name%'");    
    $results = $req->fetchAll();

    if($req->rowCount() > 0){
        foreach($results as $result){
            echo "<a class='list-group-item list-group-item-action' data-customer='". $result['customer_id'] ."'>" . ucwords($result['customer_name']) . "</a>";
        }
    }else{
        echo "<span class='list-group-item list-group-item-action'>Aucun resultat trouvé</span>";
    }

}else{
    echo "<span class='list-group-item list-group-item-action'>Aucun resultat trouvé</span>";
}