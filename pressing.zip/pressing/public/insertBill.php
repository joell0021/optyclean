<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

require("../config/init.php");
require("../vendor/autoload.php");

$user = get_user();

if(isset($_POST['articles'])){
    extract($_POST);
    
    $date_return = DateTime::createFromFormat('d/m/Y', e($return_date));
    
    $q = $db->prepare("INSERT INTO bills(bill_number, customer_id, amount, amount_paid, article_code, creation_date, retreived_date, status, user_id) VALUES(?, ?, ?, ?, ?, NOW(), ?, ?, ?)");
    $q->execute([ 
        e($bill_number),
        e($customer_id),
        e($total),
        e($amount_paid),
        e($article_code),
        $date_return->format('Y-m-d'),
        e('en-cours'),
        e($user->user_id)
    ]);

    
    try{
        $db->beginTransaction();

        for($count = 0; $count < count($articles); $count++){
            $req = $db->prepare("INSERT INTO articles_bill(bill_number, article_id, quantity) VALUES(?, ?, ?)");
            $req->execute([
                $bill_number, 
                $articles[$count], 
                $quantities[$count]
            ]);
        }

        if($db->commit()){
            $mail = new PHPMailer();
            $customer_email = get_value('email', 'customers', 'customer_id', $customer_id);

            //Server settings
            $mail->isSMTP();          
            //$mail->SMTPDebug  = SMTP::DEBUG_SERVER;                                  // Send using SMTP
            $mail->Host       = 'smtp.hostinger.com';                    // Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
            $mail->Username   = 'optyclean@growthminds.online';                     // SMTP username
            $mail->Password   = '3OslijtW';                               // SMTP password
            $mail->SMTPSecure = 'tls';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
            $mail->Port       = 587;

            //Recipients
            $mail->setFrom('optyclean@growthminds.online', 'Opty Clean');
            $mail->addAddress($customer_email);

            ob_start();
            require('mails/invoice.mail.php');
            $content = ob_get_clean();

            // Content
            $mail->isHTML(true);                                  // Set email format to HTML
            $mail->Subject = 'Opty Clean - Votre Facture';
            $mail->Body    = $content;
            //$mail->msgHTML('invoice.mail.php', __DIR__ . DIRECTORY_SEPARATOR . 'mails');

            if($mail->send()){
                echo "Facture Enregistrée";
            }
        }
    }catch(PDOException $e){
        $db->rollBack();
        die('Erreur: ' . $e->getMessage());
    }

}