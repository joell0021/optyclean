<?php
session_start();

require("../filters/guest_filter.php");
require("../config/init.php");

$user = get_user();


$q = $db->prepare("SELECT MAX(bill_number) as max_bill_num FROM bills");
$q->execute();

$result = $q->fetch(PDO::FETCH_OBJ);

$bill_number = null;

if($result && $result->max_bill_num){
    $bill_number = "00" . $result->max_bill_num;
    ++$bill_number;
}else{
    $bill_number = "001";
}

$article_code = random(4);

require("views/new-bill.view.php");