<?php
session_start();
require("../filters/guest_filter.php");
require("../config/init.php");

if(isset($_GET['bill_id']) && !empty($_GET['bill_id'])){
    $pageTitle = "Détail facture";

    if(is_already_in_use("customer_id", "bills", "bill_number", $_GET['bill_id']) > 0){
        $q= $db->prepare("SELECT * FROM bills WHERE bill_number= ? ");
        $q->execute([$_GET['bill_id']]);
        $bill = $q->fetch(PDO::FETCH_OBJ);

        $req = $db->prepare("SELECT * FROM articles_bill WHERE bill_number = ?");
        $req->execute([$_GET['bill_id']]);
        $articles = $req->fetchAll();

        $sql = $db->prepare("SELECT * FROM customers WHERE customer_id = ?");
        $sql->execute([$bill->customer_id]);
        $customer = $sql->fetch(PDO::FETCH_OBJ);

    }else{
        alertify("Parametre invalide", "error");
        redirect("factures/en-cours");
    }   
}else{
    alertify("Parametre invalide", "error");
    redirect($_SERVER['HTTP_REFERER']);
}


require("views/invoice-detail.view.php");