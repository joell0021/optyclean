<?php
session_start();

require("../filters/guest_filter.php");
require("../config/init.php");

$user = get_user();

$req = $db->prepare("SELECT * FROM users ORDER BY user_id ASC");
$req->execute(); 
$users = $req->fetchAll(PDO::FETCH_ASSOC);

if(isset($_POST['add'])){
    if(not_empty(['name', 'profile', 'username', 'password'])){

        extract($_POST);

        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        $q= $db->prepare("INSERT INTO users(name, username, password, profile) VALUES(:name, :username,:password,:profile)");
        $q->execute([
            'name' => $name,
            'username' => $username,
            'password' => $password_hash,
            'profile' => $profile 
        ]);

        alertify("Utilisateur ajouté", "success");
        redirect("gestion-des-utilisateurs");

    }else{
        alertify("Formulaire invalide", "error");
    }
}else{
    clear_input_data();
}


require("views/utilisateur.view.php");