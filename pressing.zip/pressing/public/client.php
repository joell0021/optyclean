<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

require("../filters/guest_filter.php");
require("../config/init.php");
require("../vendor/autoload.php");

$user = get_user();

$req = $db->prepare("SELECT * FROM customers");
$req->execute();
$customers = $req->fetchAll(PDO::FETCH_ASSOC);



if(isset($_POST['add']) || isset($_POST['edit'])){
    if(not_empty(['customer_name', 'customer_phone'])){

        $errors = [];
        extract($_POST);

        if(strlen($customer_name) < 3){
            $errors[]= "Nom trop court";
        }elseif(strpbrk($customer_name, '0123456789') != false){
            $errors[] = 'Nom invalide';
        }

        if(substr($customer_phone, 0, 1) != "6" || strlen($customer_phone) != 9 || !preg_match("/[^0-9]/", $customer_phone) === false){
            $errors[] = 'Numméro de téléphone invalide';
        }

        if(!empty($customer_email) && !filter_var($customer_email, FILTER_VALIDATE_EMAIL)){
            $errors[] = 'E-mail invalide';
        }

        if(isset($add) && is_already_in_use('customer_id', 'customers', 'phone', e($customer_phone)) > 0){
            $errors[] = "Numéro de téléphone déjà utilisé";
        }

        if(isset($add) && is_already_in_use('customer_id', 'customers', 'email', e($customer_email)) > 0){
            $errors[] = "E-mail déjà utilisé";
        }

        if(count($errors) == 0){
            if(isset($edit) && !empty($customer_id)){
                $req = $db->prepare("UPDATE customers SET customer_name = :customer_name, email = :email, phone = :phone WHERE customer_id = {$customer_id}");
            }elseif(isset($add) && !empty($customer_gender)){
                $req = $db->prepare("INSERT INTO customers(customer_name, email, phone, gender) VALUES(:customer_name, :email, :phone, :gender)");
            }else{
                alertify("Formulaire invalide", "error");
            }

            $config = [
                'customer_name' => e($customer_name),
                'email' => !empty($customer_email) ? e($customer_email) : null,
                'phone' => e($customer_phone)
            ];

            if(isset($add)){
                $config += ['gender' => e($customer_gender)];
            }

            $req->execute($config);

            if($req){
                //envoyer le mail uniquement si l'email est present
                if(isset($add) && !empty($customer_email)){
                    $mail = new PHPMailer();

                    //Server settings
                    $mail->isSMTP();          
                    //$mail->SMTPDebug  = SMTP::DEBUG_SERVER;                                  // Send using SMTP
                    $mail->Host       = 'smtp.hostinger.com';                    // Set the SMTP server to send through
                    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
                    $mail->Username   = 'optyclean@growthminds.online';                     // SMTP username
                    $mail->Password   = '3OslijtW';                               // SMTP password
                    $mail->SMTPSecure = 'tls';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
                    $mail->Port       = 587;

                    //Recipients
                    $mail->setFrom('optyclean@growthminds.online', 'Opty Clean');
                    $mail->addAddress($customer_email);

                    ob_start();
                    require('mails/customer.mail.html');
                    $content = ob_get_clean();
 
                    // Content
                    $mail->isHTML(true);                                  // Set email format to HTML
                    $mail->Subject = 'Bienvenu - Opty Clean';
                    $mail->Body    = $content;
                    //$mail->msgHTML('customer.mail.html', __DIR__ . DIRECTORY_SEPARATOR . 'mails');

                    $mail->send();
                }
                alertify("Client " . (isset($edit) ? 'Modifié' : 'Ajouté'), "success");
                redirect("gestion-des-clients");
            }else{
                $errors[] = "Une erreur est survenu...";
            }
        }else{
            alertify("Une erreur est survenu", "error");
            if(isset($_POST['add'])){
                save_input_data();
            }
        }
    }else{
        $errors[] = "Veuillez remplir tous les champs svp!";
        if(isset($_POST['add'])){
            save_input_data();
        }
    }
}else{
    clear_input_data();
}

require("views/client.view.php");