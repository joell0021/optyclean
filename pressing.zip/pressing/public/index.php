<?php
session_start();

require("../filters/guest_filter.php");
require("../config/init.php");

$user = get_user();

$hasOpenInvoice = getOpenInvoice();

require("views/index.view.php");