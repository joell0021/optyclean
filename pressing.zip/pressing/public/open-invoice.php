<?php
session_start();

require("../filters/guest_filter.php");
require("../config/init.php");

$user = get_user();


$today = date("Y-m-d");

$req = $db->prepare("SELECT * FROM bills WHERE(retreived_date < :today AND status = :status)");
$req->execute([
    'today' => $today,
    'status' => 'en-cours'
]);

$bills = $req->fetchAll();
$numberBills = $req->rowCount();

require("views/open-invoice.view.php");