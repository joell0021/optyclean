<?php
session_start();

require("../config/init.php");

if(isset($_POST['profile']) && !empty($_POST['profile'])){

    echo "opty-" . random(4);

}