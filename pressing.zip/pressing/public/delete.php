<?php
session_start();

require("../filters/guest_filter.php");
require("../config/init.php");

$user = get_user();

$previousPage = str_replace(WEBSITE_URL . '/', '', $_SERVER['HTTP_REFERER']);

if(isset($_GET['item']) && isset($_GET['id']) && !empty($_GET['item']) && !empty($_GET['id'])){

    extract($_GET);

    $table = $item . 's';
    $reference = ($item == "bill") ? $item . '_number' : $item . '_id';

    $q = $db->prepare("SELECT * FROM {$table} WHERE {$reference} = ?");
    $q->execute([$id]);

    if($q->rowCount() > 0){

        if($item == "bill"){

            $req= $db->prepare("DELETE FROM articles_bill WHERE {$reference} = ? ");
            $req->execute([$id]);

            $req= $db->prepare("DELETE FROM bills WHERE {$reference} = ? ");
            $req->execute([$id]);

        }else{
            $req = $db->prepare("DELETE FROM {$table} WHERE {$reference} = ?");
            $req->execute([$id]);
        }

        alertify("$item delete", "success");
        redirect($previousPage);

    }else{
        alertify("$item invalide", "error");
        redirect($previousPage);
    }

}else{
    alertify("Paramétre invalide", "error");
    redirect("/");
}