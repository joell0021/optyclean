<?php
require("../config/init.php");

if(isset($_POST['article']) && !empty($_POST['article'])){
    extract($_POST);

    $q= $db->prepare("SELECT price FROM articles WHERE article_id = ?");
    $q->execute([$article]);

    $result = $q->fetch(PDO::FETCH_OBJ);

    echo $result->price;
}