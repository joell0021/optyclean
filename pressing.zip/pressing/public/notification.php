<?php
session_start();

require("../filters/guest_filter.php");
require("../config/init.php");

$user = get_user();


require("views/notification.view.php");