<?php
session_start();

require("../filters/guest_filter.php");
require("../config/init.php");
require("../vendor/autoload.php");

$user = get_user();

if($_GET['status'] == "soldees"){
    $pageTitle = "Soldées";
}else{
    $pageTitle = str_replace('-', ' ', $_GET['status']);
}

$q= $db->prepare("SELECT * FROM bills WHERE status = ? ORDER BY creation_date DESC");
$q->execute([$_GET['status']]);

$numberBills = $q->rowCount();
$bills = $q->fetchAll();


if(isset($_POST['solder'])){
    if(not_empty(['amount', 'amount_paid', 'remainder'])){
        extract($_POST);

        $req = $db->prepare("UPDATE bills SET amount_paid = :amount_paid, status = :status WHERE bill_number = :bill_number");
        $req->execute([
            'amount_paid' => e($amount_paid + $remainder),
            'status' => 'soldees',
            'bill_number' => $bill_number
        ]);

        if($req){
            alertify("Facture Solder", "success");
            redirect('factures/soldees');
        }
    }else{
        alertify('Données invalide', 'error');
    }
}
  
if(isset($_POST['suspend'])){
    if(not_empty(['comment']) && str_word_count($_POST['comment']) >= 10){
        $req = $db->prepare("UPDATE bills SET status = :status, suspension_motif = :suspension_motif  WHERE bill_number = :bill_number");
        $req->execute([
            'status' => e("suspendu"),
            'suspension_motif' => e($_POST['comment']),
            'bill_number' => e($_POST['bill_number'])
        ]);
        if($req){
            alertify("Facture suspendu", "success");
            redirect('factures/suspendu');
        }
    }else{
        alertify('impossible de suspendre', 'error');
    }
    
}

require("views/invoice.view.php");