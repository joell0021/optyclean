<?php
if(isset($_SESSION['auth']) && !empty($_SESSION['auth'])){
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: /accueil");
    exit();
}