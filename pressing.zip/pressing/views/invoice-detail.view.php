<?php $title = ucwords($pageTitle);
require("../layouts/_header.php"); ?>
<div class="container" style="margin-top: 50px;">
    <div class="offset-xl-2 col-xl-8 col-lg-12 col-md-12 col-sm-12 padding" id="invoiceDetails">

        <div class="row pos-relative">
            <div class="col-md-6">
                <a href="/factures/<?= strtolower($bill->status) ?>" class="btn btn-light"><i class="fas fa-arrow-left"></i>&nbsp;Retour</a>
            </div>
            <div class="col-md-6">
                <button type="button" class="btn btn-outline-primary mb-3 float-right" id="printButton" onclick="ExportPdf()">Imprimer</button>
            </div>
        </div>
        
        <div class="card" id="printContent">
            <div class="card-header p-4">
                <a class="pt-2 d-inline-block" href="">
                    Opty Clean Pressing
                </a>
                <div class="float-right">
                    <h3 class="mb-0">Facture <?= $_GET['bill_id']?></h3>
                
                    <?= date("d/m/Y à H:i", strtotime($bill->creation_date)) ?>
                </div>
            </div>

            <div class="card-body">
                <div class="row" mb-4>
                    <div class="col-sm-6">
                        <h5 class="mb-3">À:</h5>
                        <h3 class="text-dark mb-1"><?= strtoupper($customer->customer_name) ?></h3>
                        <div><?= formatPhoneNumber($customer->phone) ?></div>
                        <div><?= e($customer->gender) == "H" ? "Homme" : "Femme" ?></div>
                        <div><?= e($customer->email) ?></div>
                    </div>
                    <div class="col-sm-6">
                        <h5 class="mb-3">Infos:</h5>
                        <div>Code des articles: <strong><?= $bill->article_code ?></strong></div>
                        <?php  ?>
                        <div>Date de Retrait: <?php setlocale(LC_TIME, "fr_FR", "French"); echo strftime('%A %d %B %G', strtotime($bill->retreived_date)) ?></div>
                    </div>
                </div>
                <div class="table-responsive-sm">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Articles</th>
                                <th class="center">Qte</th>
                                <th class="right">PU</th>
                                <th class="right">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($articles as $article): extract($article)?>
                            <?php 
                                $article_name = get_value('article_name', 'articles', 'article_id', $article_id);
                                $article_price = get_value('price', 'articles', 'article_id', $article_id);
                            ?>
                                <tr>
                                    <td class="left strong"><?= ucwords($article_name) ?></td>
                                    <td class="left"><?= e($quantity) ?></td>
                                    <td class="right"><?= number_format($article_price) ?> FCFA</td>
                                    <td class="right"><?= number_format($quantity * $article_price) ?> FCFA</td>
                                </tr>   
                            <?php endforeach ?>
                        </tbody>
                    </table>
                </div>
                <div class="row">
                    <div class="col-lg-5 col-sm-5 ml-auto">
                        <table class="table table-clear">
                            <tbody>
                                <tr>
                                    <td class="left">
                                        <strong class="text-dark">Avance</strong>
                                    </td>
                                    <td class="right"><?= number_format($bill->amount_paid) ?> FCFA</td>
                                </tr>
                                <tr>
                                    <td class="left">
                                        <strong class="text-dark">Reste</strong>
                                    </td>
                                    <td class="right"><?= number_format($bill->amount - $bill->amount_paid)?> FCFA</td>
                                </tr>
                                <tr>
                                    <td class="left">
                                        <strong class="text-dark">TOTAL</strong>
                                    </td>
                                    <td class="right"><?= number_format($bill->amount) ?> FCFA</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-white">
                <p class="mb-0">Opty Clean pressing, Merci pour votre visite et à bientôt.</p>
            </div>
        </div>
    </div>
</div>
    <?php require("../layouts/_footer.php"); ?>