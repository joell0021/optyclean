<?php $title = "Factures"; require("../layouts/_header.php"); ?>

<div class="container" style="margin-top: 50px">
    <div class="row">
        <div class="col-md-2">
            <a href="/accueil" class="btn btn-light"><i class="fas fa-arrow-left"></i>&nbsp;Retour</a>
        </div>
        <div class="col-md-8 text-center display-4">
            <h1><?= ucwords($title) ?></h1>
        </div>        
        <div class="col-md-2"></div>
    </div>
    <?php include("../layouts/_breadcrumb.php"); ?>
    <div class="modules">
        <div class="module-item">
            <a href="/factures/nouvelle-facture">
                <i class="fas fa-file-medical fa-5x"></i>
                <br>
                <span>Creer une facture</span>
            </a>
        </div>
        <div class="module-item">
            <a href="/factures/en-cours">
                <i class="fas fa-file-invoice fa-5x"></i>
                <br>
                <span>Factures en cours</span>
            </a>
        </div>
        <div class="module-item">
            <a href="/factures/soldees">
                <i class="fas fa-file-alt fa-5x"></i>
                <br>
                <span>Factures soldées</span>
            </a>
        </div>
        <div class="module-item">
            <a href="/factures/suspendu">
                <i class="fa fa-file-excel fa-5x"></i>
                <br>
                <span>Factures suspendues</span>
            </a>
        </div>
    </div>
</div>

<?php require("../layouts/_footer.php"); ?>