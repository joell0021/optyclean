<?php $title = "Authentification";
 require("layouts/_header.php");?>

<div class="container" style="margin-top: 80px">
    <!-- <div class="row">
        <div class="col-md-6 offset-md-3">
            <form action="" class="jumbotron" method="post" autocomplete="off">
                <?php //require("../layouts/_errors.php"); ?>
                <div class="form-group">
                    <label for="username" class="control-label">Nom d'utilisateur:</label>
                    <input type="text" name="username" id="username" value="" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="password" class="control-label">Mot de passe:</label>
                    <input type="password" name="password" id="password" class="form-control" required>
                </div>
                <div class="form-group">
                    <input type="submit" value="Connexion" name="login" class="btn btn-success btn-lg">
                </div>
            </form>
        </div>
    </div> -->
    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100">
                <form class="login100-form validate-form p-l-55 p-r-55 p-t-178" method="post" autocomplete="off">
                    <span class="login100-form-title">
                        Authentification
                    </span>
                    <?php require("layouts/_errors.php"); ?>
                    <div class="wrap-input100 validate-input m-b-16" data-validate="Please enter username">
                        <input class="input100" type="text" name="username" value="<?= get_input("username") ?>" placeholder="Nom d'utilisateur" required="required">
                        <span class="focus-input100"></span>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Please enter password">
                        <input class="input100" type="password" name="password" placeholder="Mot de passe" required="required">
                        <span class="focus-input100"></span>
                    </div>

                    <div class="container-login100-form-btn">
                        <button type="submit" name="login" class="login100-form-btn">
                            Connexion
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require("layouts/_footer.php"); ?>