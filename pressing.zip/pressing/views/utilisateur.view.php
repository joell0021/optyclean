<?php $title = "Gestion des utilisateurs"; require("../layouts/_header.php"); ?>

<div class="container" style="margin-top: 50px">
    <div class="row">
        <div class="col-md-2">
            <a href="/accueil" class="btn btn-light"><i class="fas fa-arrow-left"></i>&nbsp;Retour</a>
        </div>
        <div class="col-md-8 text-center display-4">
            <h1><?= ucwords($title) ?></h1>
        </div>
        <div class="col-md-2"></div>
    </div>

    <?php include("../layouts/_breadcrumb.php"); ?>

    <div class="row mt-5 mb-3">
        <div class="col-md-2">
            <div class="alert alert-info text-center">
                Total: <?= $req->rowCount(); ?>
            </div>
        </div>
        <div class="col-md-3 offset-7">
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-outline-info btn-lg float-right" data-toggle="modal"
                data-target="#ajoutUtilisateur">
                <i class="fa fa-plus"></i>&nbsp;Ajouter un utilisteur
            </button>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="ajoutUtilisateur" tabindex="-1" role="dialog"
            aria-labelledby="ajoutUtilisateurLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ajoutUtilisateurLabel">Ajouter un utilisateur</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form method="post" autocomplete="off">
                        <div class="modal-body">
                            <?php require("../layouts/_errors.php"); ?>
                            <div class="form-group">
                                <label for="name" class="control-label">Nom de l'utlisateur</label>
                                <input type="text" name="name" id="name" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="profile" class="control-label">Pofil</label>
                                <select name="profile" id="profile" class="form-control">
                                    <option value=""></option>
                                    <option value="admin">Administrateur</option>
                                    <option value="employer">Employer</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="username" class="control-label">Identifiant</label>
                                <input type="text" name="username" id="username" class="form-control" readonly required>
                            </div>
                            <div class="form-group">
                                <label for="password" class="control-label">Mot de passe</label>
                                <input type="text" name="password" id="password" class="form-control" readonly required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                            <button type="submit" class="btn btn-primary" name="add">Ajouter</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php if($req->rowCount() > 0): ?>
    <table class="table table-borderless table-striped table-hover" id="table">
        <thead class="thead-dark">
            <tr>
                <th>Nom de l'utilisateur</th>
                <th>Identifiant</th>
                <th>Profil</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($users as $user): ?>
            <tr>
                <td><?= ucwords($user['name']) ?></td>
                <td><?= ucwords($user['username']) ?></td>
                <td><?= $user['profile'] ?></td>
                <td>
                    <div class="row">
                        <?php if($_SESSION['auth'] == 1): ?>
                        <div class="col-sm-3">
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modifierUtilisateur<?= $user['user_id'] ?>">
                                <i class="fa fa-edit"></i>
                            </button>
                        </div>
                        <?php endif ?>
                        <?php if($user['user_id'] != 1 && $_SESSION['auth'] != $user['user_id']): ?>
                        <div class="col-sm-3">
                            <button type="button" class="btn btn-danger"
                                onclick="deleteItem('user', <?= $user['user_id'] ?>)">
                                <i class="fa fa-trash"></i>
                            </button>
                        </div>
                        <?php endif ?>
                    </div>
                </td>
                <!-- Modal -->
                <div class="modal fade" id="modifierUtilisateur<?= $user['user_id'] ?>" tabindex="-1" role="dialog"
                    aria-labelledby="modifierUtilisateur<?= $user['user_id'] ?>Label" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modifierUtilisateur<?= $user['user_id'] ?>Label">Changer le mot de passe de <?= $user['username'] ?></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form method="post" autocomplete="off">
                                <div class="modal-body">
                                    <?php require("../layouts/_errors.php"); ?>
                                    <div class="form-group">
                                        <label for="username" class="control-label">Nom de l'utilisateur</label>
                                        <input type="text" name="username" id="username" class="form-control" readonly
                                            required>
                                    </div>
                                    <div class="form-group">
                                        <label for="profile" class="control-label">Pofil</label>
                                        <select name="profile" id="profile" class="form-control">
                                            <option value=""></option>
                                            <option value="admin">Administrateur</option>
                                            <option value="employer">Employer</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="password" class="control-label">Mot de passe</label>
                                        <input type="text" name="password" id="password" class="form-control" readonly
                                            required>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                                    <button type="submit" class="btn btn-primary" name="add">Ajouter</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
    <?php else: ?>
    <div class="alert alert-info">
        Aucun Utilisateur
    </div>
    <?php endif ?>
</div>

<?php require("../layouts/_footer.php"); ?>