<?php $title = ucwords($pageTitle);
require("../layouts/_header.php"); ?>

<div class="container" style="margin-top: 50px">
    <div class="row">
        <div class="col-md-2">
            <a href="/factures" class="btn btn-light"><i class="fa fa-arrow-left"></i>&nbsp;Retour</a>
        </div>
        <div class="col-md-8 text-center display-4">
            <h1><?= ucwords($title) ?></h1>
        </div>
        <div class="col-md-2"></div>
    </div>
    <?php include("../layouts/_breadcrumb.php"); ?>
    <?php if($numberBills > 0): ?>
    <table class="table table-bordered table-striped table-hover mt-5" id="table">
        <thead class="thead-dark">
            <tr>
                <th>Facture N°</th>
                <th>Nom client</th>
                <th>Montant</th>
                <?php if($_GET['status'] == "suspendu"): ?>
                    <th width="30%">Motif de suspension</th>
                <?php else: ?>
                    <th>Date retrait</th>
                <?php endif?>
                <?php if($user->profile == "admin"): ?>
                <th>Fait Par</th>
                <?php endif ?>
                <th>Appercu</th>
                <?php if(($user->profile == "employer" && $_GET['status'] == "en-cours") || $user->profile == "admin"): ?>
                <th>Action</th>
                <?php endif ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($bills as $bill) : ?>
            <?php
                $customer_name = get_value('customer_name', 'customers', 'customer_id', $bill['customer_id']);
                $userName = get_value('name', 'users', 'user_id', $bill['user_id']);
                $userUserName = get_value('username', 'users', 'user_id', $bill['user_id']);
            ?>
                <tr>
                    <td><?= $bill['bill_number'] ?></td>
                    <td><?= ucwords($customer_name) ?></td>
                    <td><?= number_format($bill['amount']) ?> FCFA</td>
                    <?php if($_GET['status'] == "suspendu"): ?>
                    <td><?= nl2br($bill['suspension_motif']) ?></td>
                    <?php else: ?>
                    <td><?= date("d/m/Y", strtotime($bill['retreived_date'])) ?></td>
                    <?php endif?>
                    <?php if($user->profile == "admin"): ?>
                    <td><?= $userName ?>&nbsp;(<?= $userUserName ?>)</td>
                    <?php endif ?>
                    <td><a href="/factures/detail/<?= $bill['bill_number'] ?>" class="btn btn-primary" >Appercu</a></td>
                    <?php if(($user->profile == "employer" && $_GET['status'] == "en-cours") || $user->profile == "admin"): ?>
                    <td>
                        <div class="row">
                            <?php if($bill['status'] == 'en-cours'): ?>
                            <div class="col-sm-3">
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#editBill<?= $bill['bill_number']?>">
                                    <i class="fa fa-edit"></i>
                                </button>
                            </div>
                            <?php endif ?>
                            <?php if($user->profile == "admin"): ?>
                            <div class="col-sm-3">
                                <button class="btn btn-danger" type="button" onclick="deleteItem('bill', '<?= $bill['bill_number']?>')">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </div>
                            <?php endif ?>
                        </div>
                    </td>
                    <?php endif ?>
                </tr>
                <div class="modal fade" id="editBill<?= $bill['bill_number'] ?>" tabindex="-1" role="dialog" aria-labelledby="editBill<?= $bill['bill_number'] ?>Label"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editBill<?= $bill['bill_number'] ?>Label">Regler la facture</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form method="post" autocomplete="off">
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="amount" class="control-label">Prix total:</label>
                                    <input type="text" name="amount_view" id="amount"
                                        value="<?= number_format($bill['amount']) ?> FCFA" class="form-control-plaintext" readonly required>
                                    <input type="hidden" name="amount" value="<?= $bill['amount'] ?>">
                                </div>
                                <div class="form-group">
                                    <label for="amount_paid" class="control-label">Avance:</label>
                                    <input type="text" name="amount_paid_view" id="amount_paid"
                                        value="<?= number_format($bill['amount_paid']) ?> FCFA" class="form-control-plaintext" readonly required>
                                    <input type="hidden" name="amount_paid" value="<?= $bill['amount_paid'] ?>">
                                </div>
                                <div class="form-group">
                                    <label for="remainder" class="control-label">Reste:</label>
                                    <input type="text" name="remainder_view" id="remainder"
                                        value="<?= number_format($bill['amount'] - $bill['amount_paid']) ?> FCFA" class="form-control-plaintext" readonly required>
                                    <input type="hidden" name="remainder" value="<?= $bill['amount'] - $bill['amount_paid'] ?>">
                                </div>
                                <div class="form-group">
                                    <input type="hidden" name="bill_number" value="<?= $bill['bill_number'] ?>">
                                </div>
                                <hr class="dropdown-divider">
                                <div class="form-group">
                                    <label for="comment" class="control-label">Motif de suspension:</label>
                                    <textarea name="comment" class="form-control" id="" cols="30" rows="10"></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                                <button type="submit" name="suspend" class="btn btn-warning">Suspendre la facture</button>
                                <button type="submit" name="solder" class="btn btn-primary">Solder la facture</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach ?>
        </tbody>
    </table>
    <?php else: ?>
        <div class="alert alert-info">
            Aucune Facture disponible
        </div>
    <?php endif ?>
</div>

<?php require("../layouts/_footer.php"); ?>