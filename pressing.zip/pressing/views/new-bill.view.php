<?php $title = "Nouvelle facture"; require("../layouts/_header.php"); ?>

<div class="container" style="margin-top: 50px">
    <div class="row">
        <div class="col-md-2">
            <a href="/factures" class="btn btn-light"><i class="fas fa-arrow-left"></i>&nbsp;Retour</a>
        </div>
        <div class="col-md-8 text-center display-4">
            <h1><?= ucwords($title) ?></h1>
        </div>
        <div class="col-md-2"></div>
    </div> 
    <?php include("../layouts/_breadcrumb.php"); ?>
    <div class="container">
        <div class="bill-box">
            <div class="bill-head">
                <!-- <h3><span>OPTY-CLEAN</span> Bonaberi Tel: xxxxxxxx</h3> -->
                <p>
                    FACTURE N°: <?php printf('%03d', $bill_number); ?> Fait le <?= date("d m Y à H:i") ?>.
                    <input type="hidden" value="<?= $bill_number ?>" class="bill_number">
                </p>
                <p>Date de Retrait: <input type="text" name="return-date" id="return-date" class="input"></p>
                <p>
                    <div class="row" style="position: relativse;">
                        <div class="col-md-4 offset-3">
                            <input type="text" name="customer_name" id="customer_name" class="form-control" placeholder="Nom du Client">
                            <div class="list-group customer-name" style="position: absolute; z-index: 2000; width: 90%;">

                            </div>
                            <input type="hidden" name="customer_id" class="customer_id">
                        </div>
                        <div class="col-md-4">
                            N° d'article: <?= strtoupper($article_code) ?>
                            <input type="hidden" class="article_code" name="article_code" value="<?= strtoupper($article_code) ?>">
                        </div>
                    </div>
                </p>
            </div>
            <div class="bill-body" style="z-index: -1;">
                <table class="table" >
                    <thead class="thead-ligth">
                        <tr>
                            <th width="30%">Article</th>
                            <th width="20%">Quantité</th>
                            <th width="30%">Total</th>
                            <th width="10%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr id="row1">
                            <td class="article-td">
                                <select class="article form-control" name="article" onclick="getOptions(this);" onchange="getArticlePrice(this)">
                                    <option value="">Selectionez un article</option>
                                    <?php //getOption(['article_id', 'article_name'], 'articles'); ?>
                                </select>
                            </td>
                            <td class="quantity-td">
                                <input type="text" name="quantity" class="quantity form-control" onkeyup="quantity(this)">
                            </td>
                            <td class="price-td">
                                <input type="number" name="price" class="price form-control" readonly>
                                <input type="hidden" name="up" class="up">
                            </td>
                            <td class="action">
                                <button type="button" name="add" class="btn btn-success" id="add">+</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
                 
                 <div class="form-group d-flex justify-content-end">
                     <div class="input-group">
                         <div class="input-group-prepend">
                             <span class="input-group-text">#</span>
                         </div>
                        <input type="text" class="form-control total" value="" name="total" readonly style="width: 150px; text-align: center;">
                        <div class="input-group-prepend">
                             <span class="input-group-text">#</span>
                         </div> 
                    </div>
                 </div>

                 <div class="form-group d-flex justify-content-end">
                    <div class="input-group">
                         <div class="input-group-prepend">
                             <span class="input-group-text">#</span>
                         </div>
                        <input type="number" class="form-control amount_paid" placeholder="Percu" value="" name="amount_paid" onkeydown="return preventChar(event)" style="width: 150px; text-align: center;">
                        <div class="input-group-prepend">
                             <span class="input-group-text">#</span>
                         </div> 
                    </div>
                 </div>

                <button type="button" class="btn btn-primary btn-lg float-right" name="save"
                    id="save">Valider</button>
            </div>
        </div>
    </div>
    

</div>

<?php require("../layouts/_footer.php"); ?> 