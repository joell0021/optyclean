<?php $title = "Gestion des clients"; require("../layouts/_header.php"); ?>

<div class="container" style="margin-top: 50px">
    <div class="row">
        <div class="col-md-2">
            <a href="/accueil" class="btn btn-light"><i class="fas fa-arrow-left"></i>&nbsp;Retour</a>
        </div>
        <div class="col-md-8 text-center display-4">
            <h1><?= ucwords($title) ?></h1>
        </div>
        <div class="col-md-2"></div>
    </div>
    <?php include("../layouts/_breadcrumb.php"); ?>
    <div class="row mt-5 mb-3">
        <div class="col-md-2">
            <div class="alert alert-info text-center">
                Total: <?= $req->rowCount(); ?>
            </div>
        </div>
        <div class="col-md-3 offset-7">
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-outline-info btn-lg float-right" data-toggle="modal"
                data-target="#ajoutClient">
                <i class="fa fa-plus"></i>&nbsp;Ajouter un client
            </button>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="ajoutClient" tabindex="-1" role="dialog" aria-labelledby="ajoutClientLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ajoutClientLabel">Ajouter un client</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form method="post" autocomplete="off">
                        <div class="modal-body">
                            <?php require("../layouts/_errors.php"); ?>
                            <div class="form-group">
                                <label for="customer_name" class="control-label">Nom complet*</label>
                                <input type="text" name="customer_name" id="customer_name"
                                    value="<?= get_input('customer_name') ?>" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="customer_phone" class="control-label">Numéro de téléphone*</label>
                                <input type="number" name="customer_phone" id="customer_phone"
                                    value="<?= get_input('customer_phone') ?>" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="customer_gender" class="control-label">Sexe*</label>
                                <select name="customer_gender" id="customer_gender" class="form-control" required>
                                    <option value=""></option>
                                    <option value="H">Homme</option>
                                    <option value="F">Femme</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="customer_email" class="control-label">E-mail</label>
                                <input type="email" name="customer_email" id="customer_email"
                                    value="<?= get_input('customer_email') ?>" class="form-control">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                            <button type="submit" class="btn btn-primary" name="add">Ajouter</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php if($req->rowCount() > 0): ?>
    <table class="table table-borderless table-striped table-hover" id="table">
        <thead class="thead-dark">
            <tr>
                <th>Nom</th>
                <th>Numéro de téléphone</th>
                <th>Sexe</th>
                <th>E-mail</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($customers as $customer): ?>
            <tr>
                <td><?= ucwords($customer['customer_name']) ?></td>
                <td><?= formatPhoneNumber($customer['phone']) ?></td>
                <td><?= $customer['gender'] ?></td>
                <td><?= !is_null($customer['email']) ? $customer['email'] : 'Pas d\'email'?></td>
                <td>
                    <div class="row">
                        <div class="col-sm-3">
                            <button type="button" class="btn btn-primary" data-toggle="modal"
                                data-target="#editCustomer<?= $customer['customer_id'] ?>">
                                <i class="fa fa-edit"></i>
                            </button>
                        </div>
                        <div class="col-sm-3">
                            <button type="button" class="btn btn-danger"
                                onclick="deleteItem('customer', <?= $customer['customer_id'] ?>)">
                                <i class="fa fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </td>
                <!-- Modal -->
                <div class="modal fade" id="editCustomer<?= $customer['customer_id']?>" tabindex="-1" role="dialog" aria-labelledby="editCustomer<?= $customer['customer_id']?>Label"
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editCustomer<?= $customer['customer_id']?>Label">Modifer le client <?= $customer['customer_name'] ?></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form method="post" autocomplete="off">
                                <div class="modal-body">
                                    <?php require("../layouts/_errors.php"); ?>
                                    <div class="form-group">
                                        <label for="customer_name" class="control-label">Nom complet</label>
                                        <input type="text" name="customer_name" id="customer_name"
                                            value="<?= $customer['customer_name'] ?>" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="customer_phone" class="control-label">Numéro de téléphone</label>
                                        <input type="number" name="customer_phone" id="customer_phone"
                                            value="<?= $customer['phone'] ?>" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="customer_email" class="control-label">E-mail</label>
                                        <input type="email" name="customer_email" id="customer_email"
                                            value="<?= $customer['email'] ?>" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <input type="hidden" name="customer_id" value="<?= $customer['customer_id'] ?>">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                                    <button type="submit" class="btn btn-primary" name="edit">Modifier</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
    <?php else: ?>
    <div class="alert alert-info">
        Aucun Client
    </div>
    <?php endif ?>
</div>

<?php require("../layouts/_footer.php"); ?>