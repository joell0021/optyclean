  <?php $title = "Accueil"; require("../layouts/_header.php");  ?>

  <div class="container" style="margin-top: 50px">
    <nav class="menu">
        <a href="accueil" class="brand">Opty Clean</a>
        <ul>
            <li><?= e(ucfirst($user->username)) ?> connecté</li>
            <li><a href="deconnexion">Déconnexion</a></li>
        </ul>
    </nav>
    <?php include("../layouts/_breadcrumb.php"); ?>
    <!-- OpenInvoice Notif -->
    <?php if($hasOpenInvoice === true): ?>
      <div class="alert alert-warning" role="alert" style="width: 500px; text-align: center; margin: 0 auto;">
        Des factures n'ont pas été soldées. <a style="text-decoration: underline;" href="/factures/non-soldees" class="alert-link">Voir les factures</a>
      </div>
    <?php endif ?>
    <!-- Modules -->
    <div class="modules">
      <div class="module-item">
        <a href="/gestion-des-clients">
          <i class="fas fa-user fa-5x"></i>
          <br>
          <span>Clients</span>
        </a>
      </div>  
      <div class="module-item">
        <a href="/gestion-des-articles">
          <i class="fas fa-tshirt fa-5x"></i>
          <span>Articles</span>
        </a>
      </div>
      <div class="module-item">
        <a href="/factures">
          <i class="fas fa-file-invoice fa-5x"></i>
          <br>
          <span>Factures</span>
        </a>
      </div>
      <?php if($user->profile == "admin"): ?>
      <div class="module-item">
        <a href="/gestion-des-utilisateurs">
          <i class="fas fa-user-tie fa-5x"></i>
          <span>Utilisateurs</span>
        </a>
      </div>
      <?php endif ?>
      <!--
      <div class="module-item">
        <a href="/notification">
          <i class="fas fa-bell fa-5x"></i>
          <span>Notifications</span>
        </a>
      </div>
      -->
    </div>
  </div>

  <?php require("../layouts/_footer.php"); ?>