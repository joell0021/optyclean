<?php $title = "Gestion des articles"; require("../layouts/_header.php"); ?>

<div class="container" style="margin-top: 50px">
    <div class="row">
        <div class="col-md-2">
            <a href="/accueil" class="btn btn-light"><i class="fas fa-arrow-left"></i>&nbsp;Retour</a>
        </div>
        <div class="col-md-8 text-center display-4">
            <h1><?= ucwords($title) ?></h1>
        </div>
        <div class="col-md-2"></div>
    </div>
    <?php include("../layouts/_breadcrumb.php"); ?>
    <div class="row mt-5 mb-3">
        <div class="col-md-2">
            <div class="alert alert-info text-center">
                Total: <?= $req->rowCount(); ?>
            </div>
        </div>
        <?php if($user->profile == "admin"): ?>
        <div class="col-md-3 offset-7">
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-outline-info btn-lg float-right" data-toggle="modal"
                data-target="#ajoutArticle">
                <i class="fa fa-plus"></i>&nbsp;Ajouter un article
            </button>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="ajoutArticle" tabindex="-1" role="dialog" aria-labelledby="ajoutArticleLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ajoutArticleLabel">Ajouter un client</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form method="post" autocomplete="off">
                        <div class="modal-body">
                            <?php require("../layouts/_errors.php"); ?>
                            <div class="form-group">
                                <label for="article_name" class="control-label">Nom de l'article</label>
                                <input type="text" name="article_name" id="article_name"
                                    value="<?= get_input('article_name') ?>" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="article_price" class="control-label">Prix de l'article</label>
                                <input type="number" name="article_price" id="article_price"
                                    value="<?= get_input('article_price') ?>" class="form-control" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                            <button type="submit" class="btn btn-primary" name="add">Ajouter</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endif ?>
    </div>

    <?php if($req->rowCount() > 0): ?>
    <table class="table table-borderless table-striped table-hover" id="table">
        <thead class="thead-dark">
            <tr>
                <th>Nom de l'article</th>
                <th>Prix</th>
                <?php if($user->profile == "admin"): ?>
                <th>Action</th>
                <?php endif ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach($articles as $article): ?>
            <tr>
                <td><?= ucwords($article['article_name']) ?></td>
                <td><?= number_format($article['price']) ?> FCFA</td>
                <?php if($user->profile == "admin"): ?>
                <td>
                    <div class="row">
                        <div class="col-sm-3">
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#editArticle<?= $article['article_id'] ?>">
                                <i class="fa fa-edit"></i>
                            </button>
                        </div>
                        <div class="col-sm-3">
                            <button type="button" class="btn btn-danger" onclick="deleteItem('article', <?= $article['article_id'] ?>)">
                                <i class="fa fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </td>
                <?php endif ?>
            </tr>
            <div class="modal fade" id="editArticle<?= $article['article_id'] ?>" tabindex="-1" role="dialog" aria-labelledby="editArticle<?= $article['article_id'] ?>Label"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editArticle<?= $article['article_id'] ?>Label">Modifier l'article</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form method="post" autocomplete="off">
                            <div class="modal-body">
                                <?php require("../layouts/_errors.php"); ?>
                                <div class="form-group">
                                    <label for="article_name" class="control-label">Nom de l'article</label>
                                    <input type="text" name="article_name" id="article_name"
                                        value="<?= $article['article_name'] ?>" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="article_price" class="control-label">Prix de l'article</label>
                                    <input type="number" name="article_price" id="article_price"
                                        value="<?= $article['price'] ?>" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <input type="hidden" name="article_id" value="<?= $article['article_id'] ?>">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                                <button type="submit" class="btn btn-primary" name="edit">Modifier</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach ?>
        </tbody>
    </table>
    <?php else: ?>
    <div class="alert alert-info">
        Aucun Article
    </div>
    <?php endif ?>
</div>

<?php require("../layouts/_footer.php"); ?>